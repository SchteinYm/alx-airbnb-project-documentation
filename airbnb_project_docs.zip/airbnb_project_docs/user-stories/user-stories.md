# User Stories

1. As a guest, I want to register an account so I can book properties.
2. As a host, I want to list a property so guests can book it.
3. As a guest, I want to search properties by location and price so I can find a place that fits my needs.
4. As a guest, I want to make a booking and pay online so I secure my reservation.
5. As a user, I want to leave a review after my stay so I can share feedback.
