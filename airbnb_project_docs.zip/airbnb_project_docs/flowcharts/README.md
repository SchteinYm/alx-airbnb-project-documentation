# Flowchart Example

Process example: user registration
Start -> Enter details -> Validate input -> Create user record -> Return success or error
