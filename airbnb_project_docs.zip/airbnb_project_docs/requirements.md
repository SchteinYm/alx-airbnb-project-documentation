# Requirements

## Overview
This project documents the backend design for an Airbnb clone. It covers features, use case diagrams, user stories, data flow diagrams, flowcharts, and technical requirements.

## Key features
- User authentication: register, login, logout
- Property management: add, edit, delete, list
- Booking system: create booking, view bookings, cancel booking
- Payment processing: integrate Stripe or PayPal
- Reviews and ratings: leave and view reviews

## How to use
1. Open each folder to see the README and diagrams.
2. The documentation is ready for manual review.
