# Features and Functionalities

Core backend features
- User authentication and profile management
- Property listing and management by hosts
- Search and filter properties by location and price
- Booking creation and management
- Payment processing and payment records
- Review and rating system
- Admin actions for managing users and properties
