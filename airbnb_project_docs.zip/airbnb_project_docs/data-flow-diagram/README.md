# Data Flow Diagram Notes

Key flows
- User registration flow: input data -> auth service -> user table -> response
- Booking flow: user selects property -> booking service -> payment service -> booking record
- Payment flow: booking triggers payment gateway -> payment confirmation -> update booking status

