# Use Case Diagram Notes

Actors
- Guest user
- Host user
- Admin

Main use cases
- Register and login
- Browse and search properties
- Host lists a property
- Guest books a property
- Guest makes payment
- Guest leaves a review
- Admin manages content
